import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

class MemGUI extends JPanel
{
   //Declare variables
   private JFrame window = new JFrame("Memory");
   private JTextArea output = new JTextArea("");
   private JTextArea scoreboard = new JTextArea("");
   private JTextField playerName = new JTextField("");
   private JButton addScore = new JButton("Submit");
   
   //Code found on https://www.quora.com/How-can-I-add-a-scrollbar-to-a-text-area-in-Java, inspired by Jo�o Henrique Viana Oliveira
   JScrollPane toScroll = new JScrollPane(scoreboard);
   
   private int choice = 0;
   private int score = 0;
   private int match = 0;
   
   //Link to other document
   MemCards MemCards = new MemCards();
   
   //Variables to make card selection
   private int genX;
   private int genY;
   private int selectX1;
   private int selectX2;
   private int selectY1;
   private int selectY2;
   private int cardSelect;
   private int cardChoice1;
   private int cardChoice2;
   
   //Cards
   private JLabel card0;
   private JLabel card1;
   private JLabel card2;
   private JLabel card3;
   private JLabel card4;
   private JLabel card5;
   private JLabel card6;
   private JLabel card7;
   private JLabel card8;
   private JLabel card9;
   private JLabel card10;
   private JLabel card11;
   private JLabel card12;
   
   private JLabel card13;
   private JLabel card14;
   private JLabel card15;
   private JLabel card16;
   private JLabel card17;
   private JLabel card18;
   private JLabel card19;
   private JLabel card20;
   private JLabel card21;
   private JLabel card22;
   private JLabel card23;
   private JLabel card24;
   private JLabel card25;
   
   private JLabel card26;
   private JLabel card27;
   private JLabel card28;
   private JLabel card29;
   private JLabel card30;
   private JLabel card31;
   private JLabel card32;
   private JLabel card33;
   private JLabel card34;
   private JLabel card35;
   private JLabel card36;
   private JLabel card37;
   private JLabel card38;
   
   private JLabel card39;
   private JLabel card40;
   private JLabel card41;
   private JLabel card42;
   private JLabel card43;
   private JLabel card44;
   private JLabel card45;
   private JLabel card46;
   private JLabel card47;
   private JLabel card48;
   private JLabel card49;
   private JLabel card50;
   private JLabel card51;
   
   //Card backs
   private JLabel back0 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back1 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back2 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back3 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back4 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back5 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back6 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back7 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back8 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back9 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back10 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back11 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back12 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   
   private JLabel back13 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back14 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back15 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back16 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back17 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back18 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back19 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back20 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back21 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back22 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back23 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back24 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back25 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   
   private JLabel back26 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back27 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back28 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back29 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back30 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back31 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back32 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back33 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back34 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back35 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back36 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back37 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back38 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   
   private JLabel back39 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back40 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back41 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back42 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back43 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back44 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back45 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back46 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back47 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back48 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back49 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back50 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   private JLabel back51 = new JLabel(new ImageIcon(getClass().getResource("Cards/blue_back.jpg")));
   
   //Card selection buttons
   private JButton pos0 = new JButton("^");
   private JButton pos1 = new JButton("^");
   private JButton pos2 = new JButton("^");
   private JButton pos3 = new JButton("^");
   private JButton pos4 = new JButton("^");
   private JButton pos5 = new JButton("^");
   private JButton pos6 = new JButton("^");
   private JButton pos7 = new JButton("^");
   private JButton pos8 = new JButton("^");
   private JButton pos9 = new JButton("^");
   private JButton pos10 = new JButton("^");
   private JButton pos11 = new JButton("^");
   private JButton pos12 = new JButton("^");
   
   private JButton pos13 = new JButton("^");
   private JButton pos14 = new JButton("^");
   private JButton pos15 = new JButton("^");
   private JButton pos16 = new JButton("^");
   private JButton pos17 = new JButton("^");
   private JButton pos18 = new JButton("^");
   private JButton pos19 = new JButton("^");
   private JButton pos20 = new JButton("^");
   private JButton pos21 = new JButton("^");
   private JButton pos22 = new JButton("^");
   private JButton pos23 = new JButton("^");
   private JButton pos24 = new JButton("^");
   private JButton pos25 = new JButton("^");
   
   private JButton pos26 = new JButton("^");
   private JButton pos27 = new JButton("^");
   private JButton pos28 = new JButton("^");
   private JButton pos29 = new JButton("^");
   private JButton pos30 = new JButton("^");
   private JButton pos31 = new JButton("^");
   private JButton pos32 = new JButton("^");
   private JButton pos33 = new JButton("^");
   private JButton pos34 = new JButton("^");
   private JButton pos35 = new JButton("^");
   private JButton pos36 = new JButton("^");
   private JButton pos37 = new JButton("^");
   private JButton pos38 = new JButton("^");
   
   private JButton pos39 = new JButton("^");
   private JButton pos40 = new JButton("^");
   private JButton pos41 = new JButton("^");
   private JButton pos42 = new JButton("^");
   private JButton pos43 = new JButton("^");
   private JButton pos44 = new JButton("^");
   private JButton pos45 = new JButton("^");
   private JButton pos46 = new JButton("^");
   private JButton pos47 = new JButton("^");
   private JButton pos48 = new JButton("^");
   private JButton pos49 = new JButton("^");
   private JButton pos50 = new JButton("^");
   private JButton pos51 = new JButton("^");
   
   public MemGUI()
   {
      setLayout(null);
      
      //Set up cards
      cardBacks();
      cardValues();
      cardPositions();
      buttons();
            
      //Output formatting
      output.setText("Welcome to Memory! Choose two cards and see if they match. Cards of the same color and face value will match. Once matched, a pair will be removed. You will win once all cards are removed. Wait for a pair to flip back over before selecting the next pair.");
      output.setFont(output.getFont().deriveFont(18.0f));
      output.setWrapStyleWord(true);
      output.setLineWrap(true);
      output.setOpaque(false);
      output.setEditable(false);
      
      //Scoreboard formatting
      scoreboard.setText("");
      scoreboard.setFont(output.getFont().deriveFont(18.0f));
      scoreboard.setWrapStyleWord(true);
      scoreboard.setLineWrap(true);
      scoreboard.setOpaque(false);
      scoreboard.setEditable(false);
      
      //Set output position
      output.setBounds(10, 510, 650, 100);
      toScroll.setBounds(10, 30, 650, 435);
      playerName.setBounds(100, 535, 200, 20);
      addScore.setBounds(305, 535, 100, 20);
      
      //Add output
      add(output);
      
      //Set window size
      window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      window.setSize(685, 690);
      window.add(this);
      window.setVisible(true);
   }
   
   //Assign each position a random card face
   public void cardValues()
   {
      int randFace;
      
      //Card0
      randFace = MemCards.getPosition(0, 0);
      card0 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card1
      randFace = MemCards.getPosition(0, 1);
      card1 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card2
      randFace = MemCards.getPosition(0, 2);
      card2 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card3
      randFace = MemCards.getPosition(0, 3);
      card3 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card4
      randFace = MemCards.getPosition(0, 4);
      card4 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card5
      randFace = MemCards.getPosition(0, 5);
      card5 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card6
      randFace = MemCards.getPosition(0, 6);
      card6 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card7
      randFace = MemCards.getPosition(0, 7);
      card7 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card8
      randFace = MemCards.getPosition(0, 8);
      card8 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card9
      randFace = MemCards.getPosition(0, 9);
      card9 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card10
      randFace = MemCards.getPosition(0, 10);
      card10 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card11
      randFace = MemCards.getPosition(0, 11);
      card11 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card12
      randFace = MemCards.getPosition(0, 12);
      card12 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      
      //Card13
      randFace = MemCards.getPosition(1, 0);
      card13 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card14
      randFace = MemCards.getPosition(1, 1);
      card14 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card15
      randFace = MemCards.getPosition(1, 2);
      card15 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card16
      randFace = MemCards.getPosition(1, 3);
      card16 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card17
      randFace = MemCards.getPosition(1, 4);
      card17 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card18
      randFace = MemCards.getPosition(1, 5);
      card18 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card19
      randFace = MemCards.getPosition(1, 6);
      card19 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card20
      randFace = MemCards.getPosition(1, 7);
      card20 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card21
      randFace = MemCards.getPosition(1, 8);
      card21 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card22
      randFace = MemCards.getPosition(1, 9);
      card22 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card23
      randFace = MemCards.getPosition(1, 10);
      card23 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card24
      randFace = MemCards.getPosition(1, 11);
      card24 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card25
      randFace = MemCards.getPosition(1, 12);
      card25 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      
      //Card26
      randFace = MemCards.getPosition(2, 0);
      card26 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card27
      randFace = MemCards.getPosition(2, 1);
      card27 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card28
      randFace = MemCards.getPosition(2, 2);
      card28 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card29
      randFace = MemCards.getPosition(2, 3);
      card29 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card30
      randFace = MemCards.getPosition(2, 4);
      card30 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card31
      randFace = MemCards.getPosition(2, 5);
      card31 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card32
      randFace = MemCards.getPosition(2, 6);
      card32 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card33
      randFace = MemCards.getPosition(2, 7);
      card33 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card34
      randFace = MemCards.getPosition(2, 8);
      card34 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card35
      randFace = MemCards.getPosition(2, 9);
      card35 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card36
      randFace = MemCards.getPosition(2, 10);
      card36 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card37
      randFace = MemCards.getPosition(2, 11);
      card37 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card38
      randFace = MemCards.getPosition(2, 12);
      card38 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      
      //Card39
      randFace = MemCards.getPosition(3, 0);
      card39 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card40
      randFace = MemCards.getPosition(3, 1);
      card40 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card41
      randFace = MemCards.getPosition(3, 2);
      card41 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card42
      randFace = MemCards.getPosition(3, 3);
      card42 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card43
      randFace = MemCards.getPosition(3, 4);
      card43 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card44
      randFace = MemCards.getPosition(3, 5);
      card44 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card45
      randFace = MemCards.getPosition(3, 6);
      card45 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card46
      randFace = MemCards.getPosition(3, 7);
      card46 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card47
      randFace = MemCards.getPosition(3, 8);
      card47 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card48
      randFace = MemCards.getPosition(3, 9);
      card48 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card49
      randFace = MemCards.getPosition(3, 10);
      card49 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card50
      randFace = MemCards.getPosition(3, 11);
      card50 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
      //Card51
      randFace = MemCards.getPosition(3, 12);
      card51 = new JLabel(new ImageIcon(getClass().getResource("Cards/Card"+randFace+".jpg")));
   }
   
   public void cardPositions()
   {
      //Set card positions
      card0.setBounds(10, 10, 50, 75);
      card1.setBounds(60, 10, 50, 75);
      card2.setBounds(110, 10, 50, 75);
      card3.setBounds(160, 10, 50, 75);
      card4.setBounds(210, 10, 50, 75);
      card5.setBounds(260, 10, 50, 75);
      card6.setBounds(310, 10, 50, 75);
      card7.setBounds(360, 10, 50, 75);
      card8.setBounds(410, 10, 50, 75);
      card9.setBounds(460, 10, 50, 75);
      card10.setBounds(510, 10, 50, 75);
      card11.setBounds(560, 10, 50, 75);
      card12.setBounds(610, 10, 50, 75);
      
      card13.setBounds(10, 130, 50, 75);
      card14.setBounds(60, 130, 50, 75);
      card15.setBounds(110, 130, 50, 75);
      card16.setBounds(160, 130, 50, 75);
      card17.setBounds(210, 130, 50, 75);
      card18.setBounds(260, 130, 50, 75);
      card19.setBounds(310, 130, 50, 75);
      card20.setBounds(360, 130, 50, 75);
      card21.setBounds(410, 130, 50, 75);
      card22.setBounds(460, 130, 50, 75);
      card23.setBounds(510, 130, 50, 75);
      card24.setBounds(560, 130, 50, 75);
      card25.setBounds(610, 130, 50, 75);
      
      card26.setBounds(10, 250, 50, 75);
      card27.setBounds(60, 250, 50, 75);
      card28.setBounds(110, 250, 50, 75);
      card29.setBounds(160, 250, 50, 75);
      card30.setBounds(210, 250, 50, 75);
      card31.setBounds(260, 250, 50, 75);
      card32.setBounds(310, 250, 50, 75);
      card33.setBounds(360, 250, 50, 75);
      card34.setBounds(410, 250, 50, 75);
      card35.setBounds(460, 250, 50, 75);
      card36.setBounds(510, 250, 50, 75);
      card37.setBounds(560, 250, 50, 75);
      card38.setBounds(610, 250, 50, 75);
      
      card39.setBounds(10, 370, 50, 75);
      card40.setBounds(60, 370, 50, 75);
      card41.setBounds(110, 370, 50, 75);
      card42.setBounds(160, 370, 50, 75);
      card43.setBounds(210, 370, 50, 75);
      card44.setBounds(260, 370, 50, 75);
      card45.setBounds(310, 370, 50, 75);
      card46.setBounds(360, 370, 50, 75);
      card47.setBounds(410, 370, 50, 75);
      card48.setBounds(460, 370, 50, 75);
      card49.setBounds(510, 370, 50, 75);
      card50.setBounds(560, 370, 50, 75);
      card51.setBounds(610, 370, 50, 75);
      
      //Add cards to window
      add(card0);
      add(card1);
      add(card2);
      add(card3);
      add(card4);
      add(card5);
      add(card6);
      add(card7);
      add(card8);
      add(card9);
      add(card10);
      add(card11);
      add(card12);
      
      add(card13);
      add(card14);
      add(card15);
      add(card16);
      add(card17);
      add(card18);
      add(card19);
      add(card20);
      add(card21);
      add(card22);
      add(card23);
      add(card24);
      add(card25);
      
      add(card26);
      add(card27);
      add(card28);
      add(card29);
      add(card30);
      add(card31);
      add(card32);
      add(card33);
      add(card34);
      add(card35);
      add(card36);
      add(card37);
      add(card38);
      
      add(card39);
      add(card40);
      add(card41);
      add(card42);
      add(card43);
      add(card44);
      add(card45);
      add(card46);
      add(card47);
      add(card48);
      add(card49);
      add(card50);
      add(card51);

   }
   
   public void cardBacks()
   {
      //Set card back positions
      back0.setBounds(10, 10, 50, 75);
      back1.setBounds(60, 10, 50, 75);
      back2.setBounds(110, 10, 50, 75);
      back3.setBounds(160, 10, 50, 75);
      back4.setBounds(210, 10, 50, 75);
      back5.setBounds(260, 10, 50, 75);
      back6.setBounds(310, 10, 50, 75);
      back7.setBounds(360, 10, 50, 75);
      back8.setBounds(410, 10, 50, 75);
      back9.setBounds(460, 10, 50, 75);
      back10.setBounds(510, 10, 50, 75);
      back11.setBounds(560, 10, 50, 75);
      back12.setBounds(610, 10, 50, 75);
      
      back13.setBounds(10, 130, 50, 75);
      back14.setBounds(60, 130, 50, 75);
      back15.setBounds(110, 130, 50, 75);
      back16.setBounds(160, 130, 50, 75);
      back17.setBounds(210, 130, 50, 75);
      back18.setBounds(260, 130, 50, 75);
      back19.setBounds(310, 130, 50, 75);
      back20.setBounds(360, 130, 50, 75);
      back21.setBounds(410, 130, 50, 75);
      back22.setBounds(460, 130, 50, 75);
      back23.setBounds(510, 130, 50, 75);
      back24.setBounds(560, 130, 50, 75);
      back25.setBounds(610, 130, 50, 75);
      
      back26.setBounds(10, 250, 50, 75);
      back27.setBounds(60, 250, 50, 75);
      back28.setBounds(110, 250, 50, 75);
      back29.setBounds(160, 250, 50, 75);
      back30.setBounds(210, 250, 50, 75);
      back31.setBounds(260, 250, 50, 75);
      back32.setBounds(310, 250, 50, 75);
      back33.setBounds(360, 250, 50, 75);
      back34.setBounds(410, 250, 50, 75);
      back35.setBounds(460, 250, 50, 75);
      back36.setBounds(510, 250, 50, 75);
      back37.setBounds(560, 250, 50, 75);
      back38.setBounds(610, 250, 50, 75);
      
      back39.setBounds(10, 370, 50, 75);
      back40.setBounds(60, 370, 50, 75);
      back41.setBounds(110, 370, 50, 75);
      back42.setBounds(160, 370, 50, 75);
      back43.setBounds(210, 370, 50, 75);
      back44.setBounds(260, 370, 50, 75);
      back45.setBounds(310, 370, 50, 75);
      back46.setBounds(360, 370, 50, 75);
      back47.setBounds(410, 370, 50, 75);
      back48.setBounds(460, 370, 50, 75);
      back49.setBounds(510, 370, 50, 75);
      back50.setBounds(560, 370, 50, 75);
      back51.setBounds(610, 370, 50, 75);
            
      //Add card backs to window
      add(back0);
      add(back1);
      add(back2);
      add(back3);
      add(back4);
      add(back5);
      add(back6);
      add(back7);
      add(back8);
      add(back9);
      add(back10);
      add(back11);
      add(back12);
      
      add(back13);
      add(back14);
      add(back15);
      add(back16);
      add(back17);
      add(back18);
      add(back19);
      add(back20);
      add(back21);
      add(back22);
      add(back23);
      add(back24);
      add(back25);
      
      add(back26);
      add(back27);
      add(back28);
      add(back29);
      add(back30);
      add(back31);
      add(back32);
      add(back33);
      add(back34);
      add(back35);
      add(back36);
      add(back37);
      add(back38);
      
      add(back39);
      add(back40);
      add(back41);
      add(back42);
      add(back43);
      add(back44);
      add(back45);
      add(back46);
      add(back47);
      add(back48);
      add(back49);
      add(back50);
      add(back51);
   }
   
   public void buttons()
   {
      //Set button positions
      pos0.setBounds(10, 90, 50, 30);
      pos1.setBounds(60, 90, 50, 30);
      pos2.setBounds(110, 90, 50, 30);
      pos3.setBounds(160, 90, 50, 30);
      pos4.setBounds(210, 90, 50, 30);
      pos5.setBounds(260, 90, 50, 30);
      pos6.setBounds(310, 90, 50, 30);
      pos7.setBounds(360, 90, 50, 30);
      pos8.setBounds(410, 90, 50, 30);
      pos9.setBounds(460, 90, 50, 30);
      pos10.setBounds(510, 90, 50, 30);
      pos11.setBounds(560, 90, 50, 30);
      pos12.setBounds(610, 90, 50, 30);
      
      pos13.setBounds(10, 210, 50, 30);
      pos14.setBounds(60, 210, 50, 30);
      pos15.setBounds(110, 210, 50, 30);
      pos16.setBounds(160, 210, 50, 30);
      pos17.setBounds(210, 210, 50, 30);
      pos18.setBounds(260, 210, 50, 30);
      pos19.setBounds(310, 210, 50, 30);
      pos20.setBounds(360, 210, 50, 30);
      pos21.setBounds(410, 210, 50, 30);
      pos22.setBounds(460, 210, 50, 30);
      pos23.setBounds(510, 210, 50, 30);
      pos24.setBounds(560, 210, 50, 30);
      pos25.setBounds(610, 210, 50, 30);
      
      pos26.setBounds(10, 330, 50, 30);
      pos27.setBounds(60, 330, 50, 30);
      pos28.setBounds(110, 330, 50, 30);
      pos29.setBounds(160, 330, 50, 30);
      pos30.setBounds(210, 330, 50, 30);
      pos31.setBounds(260, 330, 50, 30);
      pos32.setBounds(310, 330, 50, 30);
      pos33.setBounds(360, 330, 50, 30);
      pos34.setBounds(410, 330, 50, 30);
      pos35.setBounds(460, 330, 50, 30);
      pos36.setBounds(510, 330, 50, 30);
      pos37.setBounds(560, 330, 50, 30);
      pos38.setBounds(610, 330, 50, 30);
      
      pos39.setBounds(10, 450, 50, 30);
      pos40.setBounds(60, 450, 50, 30);
      pos41.setBounds(110, 450, 50, 30);
      pos42.setBounds(160, 450, 50, 30);
      pos43.setBounds(210, 450, 50, 30);
      pos44.setBounds(260, 450, 50, 30);
      pos45.setBounds(310, 450, 50, 30);
      pos46.setBounds(360, 450, 50, 30);
      pos47.setBounds(410, 450, 50, 30);
      pos48.setBounds(460, 450, 50, 30);
      pos49.setBounds(510, 450, 50, 30);
      pos50.setBounds(560, 450, 50, 30);
      pos51.setBounds(610, 450, 50, 30);
      
      //Add buttons to window
      add(pos0);
      add(pos1);
      add(pos2);
      add(pos3);
      add(pos4);
      add(pos5);
      add(pos6);
      add(pos7);
      add(pos8);
      add(pos9);
      add(pos10);
      add(pos11);
      add(pos12);
      
      add(pos13);
      add(pos14);
      add(pos15);
      add(pos16);
      add(pos17);
      add(pos18);
      add(pos19);
      add(pos20);
      add(pos21);
      add(pos22);
      add(pos23);
      add(pos24);
      add(pos25);
      
      add(pos26);
      add(pos27);
      add(pos28);
      add(pos29);
      add(pos30);
      add(pos31);
      add(pos32);
      add(pos33);
      add(pos34);
      add(pos35);
      add(pos36);
      add(pos37);
      add(pos38);
      
      add(pos39);
      add(pos40);
      add(pos41);
      add(pos42);
      add(pos43);
      add(pos44);
      add(pos45);
      add(pos46);
      add(pos47);
      add(pos48);
      add(pos49);
      add(pos50);
      add(pos51);
      
      //Action listeners
      pos0.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back0.setVisible(false);
            genX = 0;
            genY = 0;
            cardSelect = 0;
            choiceMade();
         }
      });
      pos1.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back1.setVisible(false);
            genX = 1;
            genY = 0;
            cardSelect = 1;
            choiceMade();
         }
      });
      pos2.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back2.setVisible(false);
            genX = 2;
            genY = 0;
            cardSelect = 2;
            choiceMade();
         }
      });
      pos3.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back3.setVisible(false);
            genX = 3;
            genY = 0;
            cardSelect = 3;
            choiceMade();
         }
      });
      pos4.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back4.setVisible(false);
            genX = 4;
            genY = 0;
            cardSelect = 4;
            choiceMade();
         }
      });
      pos5.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back5.setVisible(false);
            genX = 5;
            genY = 0;
            cardSelect = 5;
            choiceMade();
         }
      });
      pos6.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back6.setVisible(false);
            genX = 6;
            genY = 0;
            cardSelect = 6;
            choiceMade();
         }
      });
      pos7.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back7.setVisible(false);
            genX = 7;
            genY = 0;
            cardSelect = 7;
            choiceMade();
         }
      });
      pos8.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back8.setVisible(false);
            genX = 8;
            genY = 0;
            cardSelect = 8;
            choiceMade();
         }
      });
      pos9.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back9.setVisible(false);
            genX = 9;
            genY = 0;
            cardSelect = 9;
            choiceMade();
         }
      });
      pos10.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back10.setVisible(false);
            genX = 10;
            genY = 0;
            cardSelect = 10;
            choiceMade();
         }
      });
      pos11.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back11.setVisible(false);
            genX = 11;
            genY = 0;
            cardSelect = 11;
            choiceMade();
         }
      });
      pos12.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back12.setVisible(false);
            genX = 12;
            genY = 0;
            cardSelect = 12;
            choiceMade();
         }
      });
      
      pos13.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back13.setVisible(false);
            genX = 0;
            genY = 1;
            cardSelect = 13;
            choiceMade();
         }
      });
      pos14.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back14.setVisible(false);
            genX = 1;
            genY = 1;
            cardSelect = 14;
            choiceMade();
         }
      });
      pos15.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back15.setVisible(false);
            genX = 2;
            genY = 1;
            cardSelect = 15;
            choiceMade();
         }
      });
      pos16.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back16.setVisible(false);
            genX = 3;
            genY = 1;
            cardSelect = 16;
            choiceMade();
         }
      });
      pos17.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back17.setVisible(false);
            genX = 4;
            genY = 1;
            cardSelect = 17;
            choiceMade();
         }
      });
      pos18.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back18.setVisible(false);
            genX = 5;
            genY = 1;
            cardSelect = 18;
            choiceMade();
         }
      });
      pos19.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back19.setVisible(false);
            genX = 6;
            genY = 1;
            cardSelect = 19;
            choiceMade();
         }
      });
      pos20.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back20.setVisible(false);
            genX = 7;
            genY = 1;
            cardSelect = 20;
            choiceMade();
         }
      });
      pos21.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back21.setVisible(false);
            genX = 8;
            genY = 1;
            cardSelect = 21;
            choiceMade();
         }
      });
      pos22.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back22.setVisible(false);
            genX = 9;
            genY = 1;
            cardSelect = 22;
            choiceMade();
         }
      });
      pos23.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back23.setVisible(false);
            genX = 10;
            genY = 1;
            cardSelect = 23;
            choiceMade();
         }
      });
      pos24.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back24.setVisible(false);
            genX = 11;
            genY = 1;
            cardSelect = 24;
            choiceMade();
         }
      });
      pos25.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back25.setVisible(false);
            genX = 12;
            genY = 1;
            cardSelect = 25;
            choiceMade();
         }
      });
      
      pos26.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back26.setVisible(false);
            genX = 0;
            genY = 2;
            cardSelect = 26;
            choiceMade();
         }
      });
      pos27.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back27.setVisible(false);
            genX = 1;
            genY = 2;
            cardSelect = 27;
            choiceMade();
         }
      });
      pos28.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back28.setVisible(false);
            genX = 2;
            genY = 2;
            cardSelect = 28;
            choiceMade();
         }
      });
      pos29.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back29.setVisible(false);
            genX = 3;
            genY = 2;
            cardSelect = 29;
            choiceMade();
         }
      });
      pos30.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back30.setVisible(false);
            genX = 4;
            genY = 2;
            cardSelect = 30;
            choiceMade();
         }
      });
      pos31.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back31.setVisible(false);
            genX = 5;
            genY = 2;
            cardSelect = 31;
            choiceMade();
         }
      });
      pos32.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back32.setVisible(false);
            genX = 6;
            genY = 2;
            cardSelect = 32;
            choiceMade();
         }
      });
      pos33.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back33.setVisible(false);
            genX = 7;
            genY = 2;
            cardSelect = 33;
            choiceMade();
         }
      });
      pos34.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back34.setVisible(false);
            genX = 8;
            genY = 2;
            cardSelect = 34;
            choiceMade();
         }
      });
      pos35.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back35.setVisible(false);
            genX = 9;
            genY = 2;
            cardSelect = 35;
            choiceMade();
         }
      });
      pos36.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back36.setVisible(false);
            genX = 10;
            genY = 2;
            cardSelect = 36;
            choiceMade();
         }
      });
      pos37.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back37.setVisible(false);
            genX = 11;
            genY = 2;
            cardSelect = 37;
            choiceMade();
         }
      });
      pos38.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back38.setVisible(false);
            genX = 12;
            genY = 2;
            cardSelect = 38;
            choiceMade();
         }
      });
      
      pos39.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back39.setVisible(false);
            genX = 0;
            genY = 3;
            cardSelect = 39;
            choiceMade();
         }
      });
      pos40.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back40.setVisible(false);
            genX = 1;
            genY = 3;
            cardSelect = 40;
            choiceMade();
         }
      });
      pos41.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back41.setVisible(false);
            genX = 2;
            genY = 3;
            cardSelect = 41;
            choiceMade();
         }
      });
      pos42.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back42.setVisible(false);
            genX = 3;
            genY = 3;
            cardSelect = 42;
            choiceMade();
         }
      });
      pos43.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back43.setVisible(false);
            genX = 4;
            genY = 3;
            cardSelect = 43;
            choiceMade();
         }
      });
      pos44.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back44.setVisible(false);
            genX = 5;
            genY = 3;
            cardSelect = 44;
            choiceMade();
         }
      });
      pos45.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back45.setVisible(false);
            genX = 6;
            genY = 3;
            cardSelect = 45;
            choiceMade();
         }
      });
      pos46.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back46.setVisible(false);
            genX = 7;
            genY = 3;
            cardSelect = 46;
            choiceMade();
         }
      });
      pos47.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back47.setVisible(false);
            genX = 8;
            genY = 3;
            cardSelect = 47;
            choiceMade();
         }
      });
      pos48.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back48.setVisible(false);
            genX = 9;
            genY = 3;
            cardSelect = 48;
            choiceMade();
         }
      });
      pos49.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back49.setVisible(false);
            genX = 10;
            genY = 3;
            cardSelect = 49;
            choiceMade();
         }
      });
      pos50.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back50.setVisible(false);
            genX = 11;
            genY = 3;
            cardSelect = 50;
            choiceMade();
         }
      });
      pos51.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            back51.setVisible(false);
            genX = 12;
            genY = 3;
            cardSelect = 51;
            choiceMade();
         }
      });
   }
   
   public void choiceMade()
   {
      //If the user hasn't made a choice yet
      if(choice == 0)
      {
         selectX1 = genX;
         selectY1 = genY;
         cardChoice1 = cardSelect;
         choice++;
      }
      //If the user has already made their first choice
      else if(choice == 1)
      {
         selectX2 = genX;
         selectY2 = genY;
         cardChoice2 = cardSelect;
         choice++;
      }
      //If the user has made two choices
      if(choice == 2)
      {
         boolean isMatch;
         
         //Prevents a card from matching with itself
         if(selectX1 == selectX2 && selectY1 == selectY2)
         {
            isMatch = false;
         }
         else
         {
            //Checks if pair matches
            isMatch = MemCards.isMatch(selectX1, selectY1, selectX2, selectY2);
         }
         
         //Gives delay before flipping the cards back over after second selection
         Timer timer = new Timer(0, new ActionListener()
         {
            @Override
            public void actionPerformed(ActionEvent e)
            {
               if(isMatch == true)
               {
                  //Remove matched pairs
                  removeMatch(cardChoice1, cardChoice2);
                  match++;
                  if(match > 25)
                  {
                     win();
                  }
               }
               
               resetBacks();
            }
         });
         
         //Starts timer
         timer.setRepeats(false);
         timer.setInitialDelay(1500);
         timer.start();
         
         //Reset card selection variables
         genX = 0;
         genY = 0;
         selectX1 = 0;
         selectX2 = 0;
         selectY1 = 0;
         selectY2 = 0;
         cardSelect = 0;
         
         choice = 0;
      }
      //Increment score
      score++;
   }
   
   //Removes cards that have been matched
   public void removeMatch(int c1, int c2)
   {
      if(c1 == 0 || c2 == 0)
      {
         card0.setVisible(false);
         remove(back0);
         pos0.setVisible(false);
      }
      if(c1 == 1 || c2 == 1)
      {
         card1.setVisible(false);
         remove(back1);
         pos1.setVisible(false);
      }
      if(c1 == 2 || c2 == 2)
      {
         card2.setVisible(false);
         remove(back2);
         pos2.setVisible(false);
      }
      if(c1 == 3 || c2 == 3)
      {
         card3.setVisible(false);
         remove(back3);
         pos3.setVisible(false);
      }
      if(c1 == 4 || c2 == 4)
      {
         card4.setVisible(false);
         remove(back4);
         pos4.setVisible(false);
      }
      if(c1 == 5 || c2 == 5)
      {
         card5.setVisible(false);
         remove(back5);
         pos5.setVisible(false);
      }
      if(c1 == 6 || c2 == 6)
      {
         card6.setVisible(false);
         remove(back6);
         pos6.setVisible(false);
      }
      if(c1 == 7 || c2 == 7)
      {
         card7.setVisible(false);
         remove(back7);
         pos7.setVisible(false);
      }
      if(c1 == 8 || c2 == 8)
      {
         card8.setVisible(false);
         remove(back8);
         pos8.setVisible(false);
      }
      if(c1 == 9 || c2 == 9)
      {
         card9.setVisible(false);
         remove(back9);
         pos9.setVisible(false);
      }
      if(c1 == 10 || c2 == 10)
      {
         card10.setVisible(false);
         remove(back10);
         pos10.setVisible(false);
      }
      if(c1 == 11 || c2 == 11)
      {
         card11.setVisible(false);
         remove(back11);
         pos11.setVisible(false);
      }
      if(c1 == 12 || c2 == 12)
      {
         card12.setVisible(false);
         remove(back12);
         pos12.setVisible(false);
      }
      
      if(c1 == 13 || c2 == 13)
      {
         card13.setVisible(false);
         remove(back13);
         pos13.setVisible(false);
      }
      if(c1 == 14 || c2 == 14)
      {
         card14.setVisible(false);
         remove(back14);
         pos14.setVisible(false);
      }
      if(c1 == 15 || c2 == 15)
      {
         card15.setVisible(false);
         remove(back15);
         pos15.setVisible(false);
      }
      if(c1 == 16 || c2 == 16)
      {
         card16.setVisible(false);
         remove(back16);
         pos16.setVisible(false);
      }
      if(c1 == 17 || c2 == 17)
      {
         card17.setVisible(false);
         remove(back17);
         pos17.setVisible(false);
      }
      if(c1 == 18 || c2 == 18)
      {
         card18.setVisible(false);
         remove(back18);
         pos18.setVisible(false);
      }
      if(c1 == 19 || c2 == 19)
      {
         card19.setVisible(false);
         remove(back19);
         pos19.setVisible(false);
      }
      if(c1 == 20 || c2 == 20)
      {
         card20.setVisible(false);
         remove(back20);
         pos20.setVisible(false);
      }
      if(c1 == 21 || c2 == 21)
      {
         card21.setVisible(false);
         remove(back21);
         pos21.setVisible(false);
      }
      if(c1 == 22 || c2 == 22)
      {
         card22.setVisible(false);
         remove(back22);
         pos22.setVisible(false);
      }
      if(c1 == 23 || c2 == 23)
      {
         card23.setVisible(false);
         remove(back23);
         pos23.setVisible(false);
      }
      if(c1 == 24 || c2 == 24)
      {
         card24.setVisible(false);
         remove(back24);
         pos24.setVisible(false);
      }
      if(c1 == 25 || c2 == 25)
      {
         card25.setVisible(false);
         remove(back25);
         pos25.setVisible(false);
      }
      
      if(c1 == 26 || c2 == 26)
      {
         card26.setVisible(false);
         remove(back26);
         pos26.setVisible(false);
      }
      if(c1 == 27 || c2 == 27)
      {
         card27.setVisible(false);
         remove(back27);
         pos27.setVisible(false);
      }
      if(c1 == 28 || c2 == 28)
      {
         card28.setVisible(false);
         remove(back28);
         pos28.setVisible(false);
      }
      if(c1 == 29 || c2 == 29)
      {
         card29.setVisible(false);
         remove(back29);
         pos29.setVisible(false);
      }
      if(c1 == 30 || c2 == 30)
      {
         card30.setVisible(false);
         remove(back30);
         pos30.setVisible(false);
      }
      if(c1 == 31 || c2 == 31)
      {
         card31.setVisible(false);
         remove(back31);
         pos31.setVisible(false);
      }
      if(c1 == 32 || c2 == 32)
      {
         card32.setVisible(false);
         remove(back32);
         pos32.setVisible(false);
      }
      if(c1 == 33 || c2 == 33)
      {
         card33.setVisible(false);
         remove(back33);
         pos33.setVisible(false);
      }
      if(c1 == 34 || c2 == 34)
      {
         card34.setVisible(false);
         remove(back34);
         pos34.setVisible(false);
      }
      if(c1 == 35 || c2 == 35)
      {
         card35.setVisible(false);
         remove(back35);
         pos35.setVisible(false);
      }
      if(c1 == 36 || c2 == 36)
      {
         card36.setVisible(false);
         remove(back36);
         pos36.setVisible(false);
      }
      if(c1 == 37 || c2 == 37)
      {
         card37.setVisible(false);
         remove(back37);
         pos37.setVisible(false);
      }
      if(c1 == 38 || c2 == 38)
      {
         card38.setVisible(false);
         remove(back38);
         pos38.setVisible(false);
      }
      
      if(c1 == 39 || c2 == 39)
      {
         card39.setVisible(false);
         remove(back39);
         pos39.setVisible(false);
      }
      if(c1 == 40 || c2 == 40)
      {
         card40.setVisible(false);
         remove(back40);
         pos40.setVisible(false);
      }
      if(c1 == 41 || c2 == 41)
      {
         card41.setVisible(false);
         remove(back41);
         pos41.setVisible(false);
      }
      if(c1 == 42 || c2 == 42)
      {
         card42.setVisible(false);
         remove(back42);
         pos42.setVisible(false);
      }
      if(c1 == 43 || c2 == 43)
      {
         card43.setVisible(false);
         remove(back43);
         pos43.setVisible(false);
      }
      if(c1 == 44 || c2 == 44)
      {
         card44.setVisible(false);
         remove(back44);
         pos44.setVisible(false);
      }
      if(c1 == 45 || c2 == 45)
      {
         card45.setVisible(false);
         remove(back45);
         pos45.setVisible(false);
      }
      if(c1 == 46 || c2 == 46)
      {
         card46.setVisible(false);
         remove(back46);
         pos46.setVisible(false);
      }
      if(c1 == 47 || c2 == 47)
      {
         card47.setVisible(false);
         remove(back47);
         pos47.setVisible(false);
      }
      if(c1 == 48 || c2 == 48)
      {
         card48.setVisible(false);
         remove(back48);
         pos48.setVisible(false);
      }
      if(c1 == 49 || c2 == 49)
      {
         card49.setVisible(false);
         remove(back49);
         pos49.setVisible(false);
      }
      if(c1 == 50 || c2 == 50)
      {
         card50.setVisible(false);
         remove(back50);
         pos50.setVisible(false);
      }
      if(c1 == 51 || c2 == 51)
      {
         card51.setVisible(false);
         remove(back51);
         pos51.setVisible(false);
      }
   }
   
   //Returns all unmatched backs to visible
   public void resetBacks()
   {
      back0.setVisible(true);
      back1.setVisible(true);
      back2.setVisible(true);
      back3.setVisible(true);
      back4.setVisible(true);
      back5.setVisible(true);
      back6.setVisible(true);
      back7.setVisible(true);
      back8.setVisible(true);
      back9.setVisible(true);
      back10.setVisible(true);
      back11.setVisible(true);
      back12.setVisible(true);
      
      back13.setVisible(true);
      back14.setVisible(true);
      back15.setVisible(true);
      back16.setVisible(true);
      back17.setVisible(true);
      back18.setVisible(true);
      back19.setVisible(true);
      back20.setVisible(true);
      back21.setVisible(true);
      back22.setVisible(true);
      back23.setVisible(true);
      back24.setVisible(true);
      back25.setVisible(true);
      
      back26.setVisible(true);
      back27.setVisible(true);
      back28.setVisible(true);
      back29.setVisible(true);
      back30.setVisible(true);
      back31.setVisible(true);
      back32.setVisible(true);
      back33.setVisible(true);
      back34.setVisible(true);
      back35.setVisible(true);
      back36.setVisible(true);
      back37.setVisible(true);
      back38.setVisible(true);
      
      back39.setVisible(true);
      back40.setVisible(true);
      back41.setVisible(true);
      back42.setVisible(true);
      back43.setVisible(true);
      back44.setVisible(true);
      back45.setVisible(true);
      back46.setVisible(true);
      back47.setVisible(true);
      back48.setVisible(true);
      back49.setVisible(true);
      back50.setVisible(true);
      back51.setVisible(true);
   }
   
   //Once the user has won
   public void win()
   {
      //Popup congratulating the player
      JOptionPane.showMessageDialog(null, "You Won With " + score + " Total Moves");
      
      //Get user's name for scoreboard
      output.setBounds(100, 510, 150, 20);
      output.setText("Enter your name:");
      add(playerName);
      add(addScore);
      
      //Once button is pressed, adds user's score to scoreboard
      addScore.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            MemCards.addScore(playerName.getText(), score);
            add(toScroll);
            scoreboard.setText("Scoreboard: \n \n" + MemCards.scoresToString());
            
            //Hides the area where you enter your name
            output.setVisible(false);
            playerName.setVisible(false);
            addScore.setVisible(false);
         }
      });
   }
   
   public static void main(String args[])
   {
      new MemGUI();
   }
}